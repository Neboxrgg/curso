//: Playground - noun: a place where people can play

import UIKit

var rango = 0...100

for r in rango {
    
    var resto = r % 5
    var par = r % 2
    
    if r > 29 && r < 41{
        print (r, "Viva Switf!!!")
    }else if resto == 0 {
        print (r, "Bingo!!!")
    }else if par == 0 {
        print (r, "Par!!!")
    }else if par == 1 {
        print (r, "Impar!!!")
    }
 

}

